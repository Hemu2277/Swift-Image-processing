//: Playground - noun: a place where people can play

import UIKit
import CoreImage

let image = UIImage(named: "sample")!

// Process the image!


//----------------------------------------------------------------------------------

// The organisation the playground is as follows. I have implemented 3 custom filter and 2 buitin fiters. Each filter has it's parameters that can be changed to see the effect.

  var MyRBG = RGBAImage(image: image)! // Convert to editable form

// Replace the red pixels with blue
  let factor = 2 // this parameter control the intensity of


  for y in 0..<MyRBG.height{
      for x in 0..<MyRBG.width{
          let index = y*MyRBG.width + x // index of the pixel
          var pixels = MyRBG.pixels[index] // access the pixel
          let Bluediff = Int(pixels.red) - 118
          if (Bluediff>0){
            pixels.blue = UInt8(max(0,min(255, 118+Bluediff*factor)))
            MyRBG.pixels[index] = pixels
          }
        
      }
  }

// Output image
    let newGreyImage = MyRBG.toUIImage()

//----------------------------------------------------------------------------------


// Parameters that controls the effect on output image
    let RedF = 0.3
    let BlueF = 0.3
    let GreenF = 0.3
// The sum of above parameters should not be greate than 1

// Apply the filter on each pixel

    for y in 0..<MyRBG.height{
      for x in 0..<MyRBG.width{
          let index = y*MyRBG.width + x // index of the pixel
          var pixels = MyRBG.pixels[index] // access the pixel
          let v = UInt8(RedF*Double(pixels.red)+GreenF*Double(pixels.green)+BlueF*Double(pixels.blue))
              pixels.red = min(255,v)
              pixels.blue = min(255,v)
              pixels.green = min(255,v)
          MyRBG.pixels[index] = pixels
      }
  }

// Output image
    MyRBG.toUIImage()


//----------------------------------------------------------------------------------

// Green and Blue booster

    var MyRBG_gb = RGBAImage(image: image)!

    for y in 0..<MyRBG_gb.height{
        for x in 0..<MyRBG_gb.width{
            let index = y*MyRBG_gb.width + x // index of the pixel
            var pixels = MyRBG_gb.pixels[index] // access the pixel
            let m = max(pixels.green,pixels.blue)
                pixels.green = m
                pixels.blue = m
            MyRBG_gb.pixels[index] = pixels
        
        }
    }

let newImage = MyRBG_gb.toUIImage()


//----------------------------------------------------------------------------------

//  Using built in filters

    let InstantEffectImage = CIImage(image: image)

// configuration of the image filter 

    var Instantfilter =  CIFilter(name: "CIPhotoEffectInstant")
    Instantfilter?.setDefaults()
    Instantfilter?.setValue(InstantEffectImage, forKey: kCIInputImageKey)
// Output image
    let Image = Instantfilter?.outputImage


    let ProcessEffectImage = CIImage(image: image)

// configuration of the image filter

    var Processfilter =  CIFilter(name: "CIPhotoEffectProcess")
    Processfilter?.setDefaults()
    Processfilter?.setValue(ProcessEffectImage, forKey: kCIInputImageKey)
// Output image
    let ImageProcess = Processfilter?.outputImage














